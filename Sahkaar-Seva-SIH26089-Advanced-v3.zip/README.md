# Sahkaar Seva — Cooperative Gig Services Platform

A responsive front-end prototype for SIH PS ID 26089.

## Included
- Household/institution service discovery
- Electrician, plumber, carpenter, painter, cleaning, gardener, driver and caregiver categories
- Cooperative-first branding
- Worker verification, fair-wage and grievance concepts
- Worker/cooperative registration modal
- Service booking demo
- Responsive mobile layout
- No external dependencies

## Run
Open `index.html` directly in a browser.

## Production roadmap
Connect the forms/search to a FastAPI backend with PostgreSQL, JWT/RBAC, worker KYC/skill verification, cooperative admin workflows, notifications, maps, payments, ratings, grievance management and analytics.
