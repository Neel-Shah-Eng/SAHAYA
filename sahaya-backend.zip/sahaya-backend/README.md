# Sahaya Login Backend (Java / Spring Boot)

A minimal, working login/register API for the Sahaya project.

## What's inside
- `POST /api/login` — verifies email + password, returns user info on success
- `POST /api/register` — creates a new account
- Passwords are hashed with BCrypt (never stored in plain text)
- In-memory user store (no database setup needed to get started) — one demo
  account is seeded automatically:
  - **email:** `demo@sahaya.com`
  - **password:** `demo123`
- `frontend/sahaya-login.html` — the login modal wired to call this API with `fetch()`

## Requirements
- Java 17+
- Maven (or use the included wrapper if you generate one via `mvn -N wrapper:wrapper`)

## Run it
```bash
cd sahaya-backend
mvn spring-boot:run
```
The server starts on **http://localhost:8080**.

## Test it
1. Open `frontend/sahaya-login.html` directly in your browser (double-click it,
   or use a simple static server like VS Code's "Live Server").
2. Click **Login**, and sign in with `demo@sahaya.com` / `demo123`.
3. Or test the API directly:
```bash
curl -X POST http://localhost:8080/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@sahaya.com","password":"demo123"}'
```

## Next steps for your hackathon build
- **Persist real users:** swap `UserRepository` (currently in-memory) for a
  Spring Data JPA repository backed by MySQL/PostgreSQL — the interface
  (`findByEmail`, `save`, `existsByEmail`) can stay the same.
- **Sessions/tokens:** right now login just returns user info. For a real
  app add JWT (e.g. `jjwt` library) so the frontend can stay "logged in"
  across page loads via a token instead of just `sessionStorage`.
- **Lock down CORS:** `CorsConfig.java` currently allows all origins
  (`allowedOrigins("*")`) — restrict it to your deployed frontend URL
  before going live.
- **Role-based access:** since Sahaya has households, workers, and admins,
  add a `role` field to `User` and check it in your controllers.

## Project structure
```
sahaya-backend/
├── pom.xml
├── src/main/java/com/sahaya/
│   ├── SahayaApplication.java
│   ├── controller/AuthController.java
│   ├── config/CorsConfig.java
│   ├── config/GlobalExceptionHandler.java
│   ├── dto/LoginRequest.java
│   ├── dto/RegisterRequest.java
│   ├── dto/AuthResponse.java
│   ├── model/User.java
│   └── repository/UserRepository.java
├── src/main/resources/application.properties
└── frontend/sahaya-login.html
```
