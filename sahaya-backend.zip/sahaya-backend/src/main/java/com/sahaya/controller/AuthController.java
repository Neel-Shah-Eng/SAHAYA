package com.sahaya.controller;

import com.sahaya.dto.AuthResponse;
import com.sahaya.dto.LoginRequest;
import com.sahaya.dto.RegisterRequest;
import com.sahaya.model.User;
import com.sahaya.repository.UserRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class AuthController {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public AuthController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        return userRepository.findByEmail(request.getEmail())
                .filter(user -> encoder.matches(request.getPassword(), user.getPasswordHash()))
                .map(user -> ResponseEntity.ok(AuthResponse.ok(user.getName(), user.getEmail())))
                .orElseGet(() -> ResponseEntity
                        .status(HttpStatus.UNAUTHORIZED)
                        .body(AuthResponse.fail("Invalid email or password")));
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(AuthResponse.fail("An account with that email already exists"));
        }

        User user = new User(
                request.getEmail(),
                encoder.encode(request.getPassword()),
                request.getName()
        );
        userRepository.save(user);

        return ResponseEntity.ok(AuthResponse.ok(user.getName(), user.getEmail()));
    }
}
