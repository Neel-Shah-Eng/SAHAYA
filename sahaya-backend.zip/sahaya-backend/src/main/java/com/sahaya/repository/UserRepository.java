package com.sahaya.repository;

import com.sahaya.model.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simple in-memory store so the login flow works out of the box with no
 * database setup. Swap this out for a Spring Data JPA repository backed by
 * MySQL/Postgres when you're ready to persist real users.
 */
@Repository
public class UserRepository {

    private final Map<String, User> usersByEmail = new ConcurrentHashMap<>();
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public UserRepository() {
        // Seed one demo account so you can test immediately:
        // email: demo@sahaya.com  password: demo123
        usersByEmail.put(
            "demo@sahaya.com",
            new User("demo@sahaya.com", encoder.encode("demo123"), "Demo User")
        );
    }

    public Optional<User> findByEmail(String email) {
        return Optional.ofNullable(usersByEmail.get(email.toLowerCase()));
    }

    public boolean existsByEmail(String email) {
        return usersByEmail.containsKey(email.toLowerCase());
    }

    public User save(User user) {
        usersByEmail.put(user.getEmail().toLowerCase(), user);
        return user;
    }
}
